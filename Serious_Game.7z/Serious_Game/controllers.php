<?php

    function acceuil_action($error)
    {         
        require 'view/page_accueil_invite.php';    
    }

    function sign_in_action($error)
    {
        $liste=liste_filiere();        
        require 'view/page_inscription.php';

	/* $bdate = date_parse($_POST['birthdate']);
	if ($bdate["error_count"] == 0 && checkdate($bdate["month"], $bdate["day"], $bdate["year"]))
    	echo "Valid date";*/

    	$link = open_database_connection();


		if (isset($_POST['username']) && strlen($_POST['username']) >= 4)
		{
			$nom_util = mysqli_real_escape_string($link, htmlspecialchars($_POST['username']));

			if (isset($_POST['first_name']) && strlen($_POST['first_name']) >= 2)
			{
				$prenom = mysqli_real_escape_string($link, htmlspecialchars($_POST['first_name']));

				if (isset($_POST['last_name']) && strlen($_POST['last_name']) >= 2)
				{
					$nom = mysqli_real_escape_string($link, htmlspecialchars($_POST['last_name']));

					if (isset($_POST['birthdate']))
					{
						$date_naissance = mysqli_real_escape_string($link, htmlspecialchars($_POST['birthdate']));

						if (isset($_POST['location']) && strlen($_POST['location']) >= 4)
						{
							$adresse = mysqli_real_escape_string($link, htmlspecialchars($_POST['location']));
							
							if (isset($_POST['email']))
							{
								$email = mysqli_real_escape_string($link, htmlspecialchars($_POST['email']));

								if (isset($_POST['university']) && strlen($_POST['university']) >= 3)
								{
									$nom_univ = mysqli_real_escape_string($link, htmlspecialchars($_POST['university']));

									if(!empty($_POST['id_fil']))
									{
										$id_fil = $_POST['id_fil'];

										if (isset($_POST['password']) && strlen($_POST['password'] >= 7))
										{
											$mot_de_passe = mysqli_real_escape_string($link, htmlspecialchars($_POST['password']));

											if (isset($_POST['password_confirmation']) && ($_POST['password_confirmation'] == $_POST['password']))
											{
												echo "ICI ";
												$mot_de_passe_confime = mysqli_real_escape_string($link, htmlspecialchars($_POST['password_confirmation']));
												
												$id_fil = 1;

												$option_sport= empty($_POST['Option_Sport']) ? 0 : 1;
												$passwordSalted = 'sweet'.$mot_de_passe_confime;
											    $passwordHashed = hash('sha256', $passwordSalted);


			
														$error = sign_up($nom, $prenom, $date_naissance, $adresse, $email, $nom_univ, $id_fil, $nom_util, $passwordHashed, $option_sport);
														if(isset($error))
														{
															echo $error;
														}else
														{
															header("Location: page_connexion");
														}
														

											}else
											{
												echo $password_confirmationErr = "Username or Mot de passe invalide";
											}
										}else
										{
											echo $passwordErr = "Username or Mot de passe invalide";
										}
									}else
									{
										echo $filiereErr = "Filiere invalide";
									}
								}else
								{
									echo $universityErr = "Université invalide";
								}
							}else
							{
								echo $mailErr = "E-mail invalide";
							}
						}else
						{
							echo $locationErr = "Localisation invalide";
						}
					}else
					{
						echo $birthdateErr = "Date de Naissance invalide";
					}
				}else
				{
					echo $last_nameErr = "Nom de famille invalide";
				}
			}else
			{
				echo $first_nameErr = "Prénom invalide";
			}
		}else
		{
			$usernameErr = "Nom de compte ou Mot de Passe invalide";
		}

		

    }

    function login_action($error)
    {         
         require 'view/page_connexion.php';
    }

    function FAQ_action($error)
    {         
       require 'view/page_faq.php';   
    }        

    function acceuil_util_action($login, $error)   
    {                  
    	require 'view/page_accueil_utilisateur.php';   
    }

    function acceuil_admin_action($login, $error)   
    {                
    	require 'view/page_admin.php';   
    }

    function profil_action($error)
    {
         $infoprofil = recup_info_profil($_SESSION['nom_util']);
         $notes =   recup_note_profil($_SESSION['nom_util']);
         /* creer tableau avec nom filiere et note*/  
         require 'view/page_profil_utilisateur.php';
    }

    function question_action($login, $error)   
    {                  
    	require 'view/page_questions.php';   
    }

    function test_action($error)
    {
       $liste=liste_matiere();         
       require 'view/page_test.php';   
    } 

    function test_questions_action($login, $error)
    {
       $result = prepare_test($login, $_GET['id_mat']);
       $question = recup_description_question_multi($result);
       $reponse = recup_rep_multi($result);     
       require 'view/page_test_questions.php';  
    }   
?>
