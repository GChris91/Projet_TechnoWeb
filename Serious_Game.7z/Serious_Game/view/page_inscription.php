<!DOCTYPE html>

<html lang="fr">

	<head>
	
		<meta charset="utf-8">
		<link rel="stylesheet" href="/Serious_Game/view/css/style_page_inscription.css">
		<link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
		<script src="/Serious_Game/view/js/script_page_inscription.js"></script>
		<script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title> Inscription </title>
		
	</head>

	<body>
		

		<div class="container">
		        <div class="row centered-form">
		        <div class="col-xs-12 col-sm-8 col-md-4 col-sm-offset-2 col-md-offset-4">
		        	<div class="panel panel-default">
		        		<div class="panel-heading">
					    		<h3 class="panel-title">Inscription Serious Game <small>Gratuit</small></h3>
					 			</div>
					 			<div class="panel-body">
					    		
					    		<form  action="page_inscription" method="post" enctype="multipart/form-data">

					    			<div class="form-group">
					    				<input type="text" name="username" id="username" class="form-control input-sm" placeholder="Nom de Compte">
					    			</div>
					    			<div class="row">
					    				<div class="col-xs-6 col-sm-6 col-md-6">
					    					<div class="form-group">
					                					<input type="text" name="first_name" id="first_name" class="form-control input-sm floatlabel" placeholder="Prénom">
					    					</div>
					    				</div>

					    				<div class="col-xs-6 col-sm-6 col-md-6">
					    					<div class="form-group">
					    						<input type="text" name="last_name" id="last_name" class="form-control input-sm" placeholder="Nom de Famille">
					    					</div>
					    				</div>
					    			</div>

					    			<div class="form-group">
					    				<input type="date" name="birthdate" id="birthdate" class="form-control input-sm" placeholder="Date de Naissance (Format : jj/mm/aaaa)">
					    			</div>

					    			<div class="form-group">
					    				<input type="text" name="location" id="location" class="form-control input-sm" placeholder="Localisation">
					    			</div>

					    			<div class="form-group">
					    				<input type="mail" name="email" id="email" class="form-control input-sm" placeholder="Adresse Mail">
					    			</div>

					    			<div class="form-group">
					    				<input type="text" name="university" id="university" class="form-control input-sm" placeholder="Université">
					    			</div>

					    			<div class="row">
					    				<div class="col-xs-6 col-sm-6 col-md-6">
					    					<div class="form-group">
					    						<input type="password" name="password" id="password" class="form-control input-sm" placeholder="Mot de Passe">
					    					</div>
					    				</div>
					    				<div class="col-xs-6 col-sm-6 col-md-6">
					    					<div class="form-group">
					    						<input type="password" name="password_confirmation" id="password_confirmation" class="form-control input-sm" placeholder="Confirmez MdP">
					    					</div>
					    				</div>
					    			</div>

					    			<div class="branches">
					    				Filière :
						    			<select class="" name="id_fil">
						    			<option value=0>Select...</option>
						    				<?php foreach ($liste['id_fil'] as $key => $id_fil)
						    				{
						    					echo '<option value='.$id_fil.' >'.$liste['nom_fil'][$key].' </option>';
						    				}?>
				                        </select>
			                        </div>

					    			<div class="checkbox">
                						<label><input type="checkbox" value="Option Sport">Option Sport</label>
            						</div>
            						<fieldset>					
						<h3>Système anti-robots :</h3>
						<label for="captcha" class="form-control input-sm">Entrez les 8 caractères contenus dans l'image:</label> <input type="text" name="captcha" id="captcha"><br/>
						<img src="captcha.php" />
						</fieldset>
					    			
					    			<input type="submit" value="S'inscrire" class="btn btn-info btn-block">
					    		
					    		</form>
					    	</div>
			    		</div>
		    		</div>
		    	</div>
		    </div>

	</body>

</html>