<!DOCTYPE html>

<html lang="fr">

	<head>
    
        <meta charset="utf-8">
		<link rel="stylesheet" href="css/style_page_question.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js/script_page_question.js"></script>
        <script src="js/bootstrap.min.js"></script>
		

		<title> Question </title>
		
	</head>

	<body>

    <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>

    <br/>
    <br/>
    <br/>

	<div class="container">

                <!-- Jumbotron Header -->
            <header class="jumbotron hero-spacer">
                <h1>Question [Numéro X]</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa, ipsam, eligendi, in quo sunt possimus non incidunt odit vero aliquid similique quaerat nam nobis illo aspernatur vitae fugiat numquam repellat ?</p>
                </p>
            </header>



<?php
   require_once 'model.php';

    if(isset($_SESSION['nom_util']) && isset($_GET['sujet'])){
        open_database_connection();

    if($_GET['sujet'] == 'info')
        {$id_mat=1;}
    
    }else
    {
        acceuil_action($error);
    }
        $result = prepare_test($_SESSION['nom_util'], $id_mat);
        //print_r($result);
        $question = recup_description_question_multi($result);

        $reponse = recup_rep_multi($result);

        $i = 0;
        
        foreach ($question['id_q'] as $id_q1)
        {

            printf($question['description'][$i].":");                     
            $i++;
            $j=0;
        }
     ?>

     <?php

        /*echo '<pre>';
        print_r($reponse);
        echo '</pre>';*/

        $aux=array();

        foreach ($reponse['description'] as $key => $description)
        {
            if($reponse['id_q'][$key] == 1)
            {
                $aux[] = $description;
            }  
        }

        $rand_keys = array_rand($aux, 4);

        echo '<pre>';
        print_r($rand_keys);
        echo '</pre>';
        echo $aux[$rand_keys[0]] . '<br/>';
        echo $aux[$rand_keys[1]] . '<br/>';
        echo $aux[$rand_keys[2]] . '<br/>';
        echo $aux[$rand_keys[3]] . '<br/>';




               foreach ($reponse['id_q'] as $id_q2)
            {
                if($id_q1 == $id_q2)
                {
                    echo '<input type="radio" name="reponse">'.$reponse['description'][$j].'<br/>';
                }
                $j++;
            }
    ?>
                    <input type="submit" name= 'validation' value="Valider">
                    </form>
            <?php
                    //printf($reponse['description'][$j].",");
                    //echo '<tr>'.$reponse['description'][$j].'<br/><th>';
            
       }

*/
       ?>








            <hr>

            <div class="row">

                <!-- Volet de gauche -->
                
                <div class="col-sm-6">

                    <div class="business-card">
                        <div class="media">
                            
                            <div class="media-body">
                                <h2 class="media-heading">[Réponse A]</h2>
                                <br/>
                                <button type="button" class="btn btn-primary btn-sm">Small button</button>
                                
                            </div>
                        </div>
                    </div>

                    <div class="business-card">
                        <div class="media">
                            
                            <div class="media-body">
                                <h2 class="media-heading">[Réponse C]</h2>
                                <br/>
                                <button type="button" class="btn btn-primary btn-sm">Small button</button>
                                
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Volet de droite -->
                        
                <div class="col-sm-6">

                    <div class="business-card">
                        <div class="media">
                            
                            <div class="media-body">
                                <h2 class="media-heading">[Réponse B]</h2>
                                <br/>
                                <button type="button" class="btn btn-primary btn-sm">Small button</button>
                                
                            </div>
                        </div>
                    </div>

                    <div class="business-card">
                        <div class="media">
                            
                            <div class="media-body">
                                <h2 class="media-heading">[Réponse D]</h2>
                                <br/>
                                <button type="button" class="btn btn-primary btn-sm">Small button</button>
                                
                            </div>
                        </div>
                    </div>

                </div>
                
            </div>
        </div>


	</body>

</html>