<!DOCTYPE html>

<html lang="fr">

	<head>

    <meta charset="utf-8">
        <link rel="stylesheet" href="/Serious_Game/view/css/style_page_donation.css">
        <link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
        
        <script src="/Serious_Game/view/js/script_page_donation.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title> Page de don </title>
		
	</head>

	<body>


        <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>

      <br/>

    	<div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12">
            <form class="form-horizontal span6">

              <fieldset>
                <legend>Montant du don</legend>
      
                <div class="form-group">
                  <label class="control-label">Tapez le montant du don ici</label>
                  <div class="controls">
                    <input type="text" class="form-control" pattern="\w+ \w+.*" title="Montant du don" required="">
                  </div>
                </div>

                <br/>             
              
              </fieldset>

              <fieldset>
                <legend>Vos Informations</legend>
             
                <div class="form-group">
                  <label class="control-label">Nom</label>
                  <div class="controls">
                    <input type="text" class="form-control" pattern="\w+ \w+.*" title="Nom de Famille" required="">
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label">Prénom</label>
                  <div class="controls">
                    <input type="text" class="form-control" pattern="\w+ \w+.*" title="Prénom" required="">
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label">Adresse Mail</label>
                  <div class="controls">
                    <input type="text" class="form-control" pattern="\w+ \w+.*" title="Adresse Mail" required="">
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label">Numéro de téléphone</label>
                  <div class="controls">
                    <input type="text" class="form-control" pattern="\w+ \w+.*" title="Numéro de téléphone" required="">
                  </div>
                </div>

                <br/>             
              
              </fieldset>

              <fieldset>
                <legend>Informations Bancaires</legend>
             
                <div class="form-group">
                  <label class="control-label">Nom du Détenteur de la carte</label>
                  <div class="controls">
                    <input type="text" class="form-control" pattern="\w+ \w+.*" title="Nom de Famille" required="">
                  </div>
                </div>
             
                <div class="form-group">
                  <label class="control-label">Numéro de Carte</label>
                  <div class="controls">
                    <div class="row">
                      <div class="col-sm-3 col-md-3">
                        <input type="text" class="form-control" autocomplete="off" maxlength="4" pattern="\d{4}" title="First four digits" required="">
                      </div>
                    </div>
                  </div>
                </div>
             
                <div class="form-group">
                  <label class="control-label">Date d'expiration de la carte</label>
                  <div class="controls">
                    <div class="row">
                      <div class="col-sm-3 col-md-3">
                        <select class="">
                          <option>Janvier</option>
                          <option>...</option>
                          <option>Décembre</option>
                        </select>
                      </div>
                      <div class="col-sm-3 col-md-3">
                        <select class="">
                          <option>2013</option>
                          <option>...</option>
                          <option>2017</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
             
                <div class="form-group">
                  <label class="control-label">Numéro de vérification de la carte</label>
                  <div class="controls">
                    <div class="row">
                      <div class="col-sm-3 col-md-3">
                        <input type="text" class="form-control" autocomplete="off" maxlength="3" pattern="\d{3}" title="Three digits at back of your card" required="">
                      </div>
                      <div class="col-sm-8 col-md-8">
                        <!-- screenshot may be here -->
                      </div>
                    </div>
                  </div>
                </div>
             
                <div class="form-actions">
                  <button type="submit" class="btn btn-primary">Payer</button>
                  <button type="button" class="btn btn-default">Annuler</button>
                </div>

                <br/>

              </fieldset>
            </form>
          </div>
        </div>
    </div>

    
	</body>

</html>