<!DOCTYPE html>

<html lang="fr">

	<head>

        <meta charset="utf-8">
        <link rel="stylesheet" href="/Serious_Game/view/css/style_page_profil_admin.css">
        <link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
        
        <script src="/Serious_Game/view/js/script_profil_admin.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title> Profil </title>
		
	</head>

	<body>

    <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>
    

    <hr class="">
    <div class="container target">
        <div class="row">
            <div class="col-sm-10">
                 <h1 class="">Starfox221</h1>
             
              <button type="button" class="btn btn-success">Demande Amis</button>  <button type="button" class="btn btn-info">Message Privé</button>
    <br>
            </div>
          <div class="col-sm-2"><a href="/users" class="pull-right"><img title="profile image" class="img-circle img-responsive" src="http://www.rlsandbox.com/img/profile.jpg"></a>

            </div>
        </div>
      <br>
        <div class="row">
            <div class="col-sm-3">
                <!--left col-->
                <ul class="list-group">
                    <li class="list-group-item text-muted" contenteditable="false">Profile</li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Nom</strong></span> Pintade</li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Prénom</strong></span> Jean-Charles</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Filière</strong></span> Informatique
                            </li>
                  <li class="list-group-item text-right"><span class="pull-left"><strong class="">Grade </strong></span> L3
                   
                          </li>

                  <li class="list-group-item text-right"><span class="pull-left"><strong class="">Clan </strong></span> Loups de Givre
                   
                          </li>
                </ul>
              
                <ul class="list-group">
                    <li class="list-group-item text-muted">Contacts <i class="fa fa-dashboard fa-1x"></i>

                    </li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Adresse Mail</strong></span> Starfox221@gmail.com</li>
                    
                </ul>
                
            </div>
            <!--/col-3-->
            <div class="col-sm-9" style="" contenteditable="false">
                <div class="panel panel-default">
                    <div class="panel-heading">Informations Diverses</div>
                    <div class="panel-body"> Des infomations diverses

                    </div>
                </div>
            
               <div class="panel panel-default">
                    <div class="panel-heading">Informations Notes</div>
                    <div class="panel-body"> Des informations sur mes notes

                    </div>
    </div></div>


                <div id="push"></div>
            </div>
            <footer id="footer">
                    <div class="span3">
                        <span class="pull-right">©Copyright 2017 Serious Game</span>
                    </div>
                </div>
            </footer>
            
    </div>

    
	</body>

</html>