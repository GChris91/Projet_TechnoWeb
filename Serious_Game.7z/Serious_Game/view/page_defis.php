<!DOCTYPE html>

<html lang="fr">

	<head>
    
        <meta charset="utf-8">
		<link rel="stylesheet" href="/Serious_Game/view/css/style_page_defis.css">
		<link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
		<script src="/Serious_Game/view/js/script_page_defis.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title> Défis </title>
		
	</head>

	<body>

    <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>

    <br/>
    <br/>
    <br/>

	<div class="container">
            <div class="row">

                <!-- Volet des adversaires ayant envoyé un défis à l'utilisateur -->
                
                <div class="col-sm-6">

                    <div class="panel-heading c-list">
                        <span class="title">Vous avez été défié par :</span>
                    </div>

                    <div class="business-card">
                        <div class="media">
                            <div class="media-left">
                                <img class="media-object img-circle profile-img" src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png">
                            </div>
                            <div class="media-body">
                                <h2 class="media-heading">[Adversaire Défiant l'utilisateur]</h2>
                                <div class="job">[Titre Défis]</div>
                                
                            </div>
                        </div>
                    </div>

                    <div class="business-card">
                        <div class="media">
                            <div class="media-left">
                                <img class="media-object img-circle profile-img" src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png">
                            </div>
                            <div class="media-body">
                                <h2 class="media-heading">[Adversaire Défiant l'utilisateur]</h2>
                                <div class="job">[Titre Défis]</div>
                                
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Volet des adversaires défiés par l'utilisateur -->
                        
                <div class="col-sm-6">

                    <div class="panel-heading c-list">
                        <span class="title">Vous avez défié :</span>
                    </div>

                    <div class="business-card">
                        <div class="media">
                            <div class="media-left">
                                <img class="media-object img-circle profile-img" src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png">
                            </div>
                            <div class="media-body">
                                <h2 class="media-heading">[Adversaire Défié par l'utilisateur]</h2>
                                <div class="job">[Titre Défis]</div>
                                
                            </div>
                        </div>
                    </div>

                    <div class="business-card">
                        <div class="media">
                            <div class="media-left">
                                <img class="media-object img-circle profile-img" src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png">
                            </div>
                            <div class="media-body">
                                <h2 class="media-heading">[Adversaire Défié par l'utilisateur]</h2>
                                <div class="job">[Titre Défis]</div>
                                
                            </div>
                        </div>
                    </div>

                </div>
                
            </div>
        </div>


	</body>

</html>