<!DOCTYPE html>

<html lang="fr">

	<head>
	
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/style_page_inscription_confirmation.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js/script_page_inscription_confirmation.js"></script>
		<script src="js/bootstrap.min.js"></script>
		

		<title> Inscription Confirmation </title>
		
	</head>

	<body>
		

		<div class="container">
		        <div class="row centered-form">
		        <div class="col-xs-12 col-sm-8 col-md-4 col-sm-offset-2 col-md-offset-4">
		        	<div class="panel panel-default">
		        		<div class="panel-heading">
			    			<h3 class="panel-title">Inscription Serious Game <small>Gratuit</small></h3>
			 			</div>
					 			<div class="panel-body">
						    		<h2 class="text-center">Confirmation Inscription</h2>
						    		<br/>
	            					<p class="text-center">Nous vous remerçions de vous être inscrit.</p>
	            					<p class="text-center">veuillez cliquer sur le lien de confirmation ci-dessous</p>
	            					<br/>
	            					<a class="btn btn-primary btn-block" href="#" role="button">Lien de confirmation</a>
					    		</div>
			    		</div>
		    		</div>
		    	</div>
		    </div>

	</body>

</html>