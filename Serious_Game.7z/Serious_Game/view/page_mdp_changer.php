<!DOCTYPE html>

<html lang="fr">

	<head>
	
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/style_page_mdp_changer.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js/script_page_mdp_changer.js"></script>
		<script src="js/bootstrap.min.js"></script>
		

		<title> Changement de Mot de Passe </title>
		
	</head>

	<body>
		

		<div class="container">
		        <div class="row centered-form">
		        <div class="col-xs-12 col-sm-8 col-md-4 col-sm-offset-2 col-md-offset-4">
		        	<div class="panel panel-default">
		        		<div class="panel-heading">
					    		<h3 class="panel-title">Changement de Mot de Passe <small>Serious Game</small></h3>
					 			</div>
					 			<div class="panel-body">
					    		<form role="form">
					    			<div class="form-group">
					    				<input type="former_password" name="former_password" id="former_password" class="form-control input-sm" placeholder="Ancien mot de passe">
					    			</div>

					    			<div class="form-group">
					    				<input type="new_password" name="new_password" id="new_password" class="form-control input-sm" placeholder="Nouveau Mot de passe">
					    			</div>

					    			<div class="form-group">
					    				<input type="confirm_new_password" name="confirm_new_password" id="confirm_new_password" class="form-control input-sm" placeholder="Confirmer Nouveau Mot de Passe">
					    			</div>
					    			
					    			<input type="submit" value="Changer le Mot de Passe" class="btn btn-info btn-block">
					    		
					    		</form>
					    	</div>
			    		</div>
		    		</div>
		    	</div>
		    </div>

	</body>

</html>