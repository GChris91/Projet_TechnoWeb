<!DOCTYPE html>

<html lang="fr">

	<head>

        <meta charset="utf-8">
		<link rel="stylesheet" href="/Serious_Game/view/css/style_page_accueil_utilisateur.css">
		<link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
        
		<script src="/Serious_Game/view/js/scriptpage_accueil_utilisateur.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title>Accueil</title>
		
	</head>

	<body>


    <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>

    <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                   <div class="container">

                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Mon Profil
                            </div>
                            <div class="desc"><?php if (isset($_SESSION['nom_util']))
                                                                         {echo $_SESSION['nom_util'];
                                                                         }else {echo "Username";} ?></div>
                            <div class="desc"><?php if (isset($_SESSION['username']))
                                                                         {echo '<a href="page_test.php">Changer Mot de Passe</a>';
                                                                         }else {echo "Lorem Ipsum";}?></div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_profil_utilisateur" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Test
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_test" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">

                <div class="container">
                  <div class="card hovercard">
                     <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                     <div class="avatar">
                        <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                     </div>
                     <div class="info">
                        <div class="title">
                           Défis
                        </div>
                        <div class="desc">Lorem ipsum</div>
                        <div class="desc">Lorem ipsum</div>
                        <div class="desc">Lorem ipsum</div>
                     </div>
                     <div class="bottom">
                        <a class="btn btn-primary" href="page_defis.php" role="button">Link</a>
                     </div>
                  </div>
                  
                </div>                
                </div>
                
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Magasin
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_magasin.php" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Donation
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_donation.php" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Règles
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_regles.php" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               F.A.Q
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_faq.php" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Mon Clan
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_clan.php" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>
            </div>
    </div>

	</body>

</html>