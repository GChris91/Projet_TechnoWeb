<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Serious Game</title>

    <!-- Bootstrap Core CSS -->
    <link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/Serious_Game/view/css/style_page_accueil_invite.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Serious Game</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    
                    <li>
                        <a href="index.php/page_inscription">S'inscrire</a>
                    </li>
                    <li>
                        <a href="index.php/page_connexion">Se connecter</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Image Background Page Header -->
    <!-- Note: The background image is set within the business-casual.css file. -->
    <header class="business-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="tagline">La connaissance à portée de click !</h1>
                </div>
            </div>
        </div>
    </header>

    <!-- Page Content -->
    <div class="container">

        <hr>

        <div class="row">
            <div class="col-sm-8">
                <h2>Nôtre Projet</h2>
                <p>Introduce the visitor to the business using clear, informative text. Use well-targeted keywords within your sentences to make sure search engines can find the business.</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et molestiae similique eligendi reiciendis sunt distinctio odit? Quia, neque, ipsa, adipisci quisquam ullam deserunt accusantium illo iste exercitationem nemo voluptates asperiores.</p>
                <p>
                    <a class="btn btn-default btn-lg" href="index.php/FAQ">F.A.Q &raquo;</a>
                </p>
            </div>
            <div class="col-sm-4">
                <h2>Contactez Nous</h2>
                <address>
                    <strong>Serious Game</strong>
                    <br>[Insérez Adresse]
                    <br>[Insérez Adresse]
                    <br>
                </address>
                <address>
                    <abbr title="Téléphone">P:</abbr>[Insérez Téléphone]
                    <br>
                    <abbr title="Email">E:</abbr> <a href="mailto:#">[Insérez Adresse Mail]</a>
                </address>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <div class="row">
            <div class="col-sm-4">
                <img class="img-circle img-responsive img-center" src="images/Chris.gif" alt="Chris">
                <h2>GUERRESCHI Christophe</h2>
                <p>Codeur PHP</p>
            </div>
            <div class="col-sm-4">
                <img class="img-circle img-responsive img-center" src="images/Yoann.gif" alt="Yoann">
                <h2>GUIVARCH Yoann</h2>
                <p>Responsable base de données, Responsable MVC</p>
            </div>
            <div class="col-sm-4">
                <img class="img-circle img-responsive img-center" src="images/Arnaud.gif" alt="Arnaud">
                <h2>LAURENT Arnaud</h2>
                <p>Visual Designer, Codeur CSS/HMTL</p>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Serious Game 2017</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
