<!DOCTYPE html>

<html lang="fr">

	<head>

        <meta charset="utf-8">
		<link rel="stylesheet" href="/Serious_Game/view/css/style_page_test.css">
		<link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
		<script src="/Serious_Game/view/js/script_page_test.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title> Tests </title>
		
	</head>

	<body>

    <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>

    <br/>
    <br/>
    <br/>

    <div class="container">
    <div class="row">


    <?php 

        foreach ($liste['id_mat'] as $key => $id_mat) 
        {
            if($key == 0 || $key%3 == 0)
            {
                echo'<div class="col-sm-3">

                <div class="card">
                <img class="card-img-top" src="https://placeholdit.imgix.net/~text?txtsize=33&txt=250×100-1&w=250&h=100" alt="Card image cap">
                <div class="card-block">
                    <h4 class="card-title">'.$liste['titre_mat'][$key].'</h4>
                    <p class="card-text">[Description du test]</p>
                    <a href="page_test_questions?id_mat='.$id_mat.'" name= "id_mat" value="Faire le Test" class="btn btn-primary">Faire le Test</a>
                </div>
                </div>';
            }elseif(($key+1)%3 == 0)
            {
                echo'
                <div class="card">
                <img class="card-img-top" src="https://placeholdit.imgix.net/~text?txtsize=33&txt=250×100-1&w=250&h=100" alt="Card image cap">
                <div class="card-block">
                    <h4 class="card-title">'.$liste['titre_mat'][$key].'</h4>
                    <p class="card-text">[Description du test]</p>
                   <a href="page_test_questions?id_mat='.$id_mat.'" name= "id_mat" value="Faire le Test" class="btn btn-primary">Faire le Test</a>
                </div>
                </div>

                </div>';
            }else
            {
                echo'
                <div class="card">
                <img class="card-img-top" src="https://placeholdit.imgix.net/~text?txtsize=33&txt=250×100-1&w=250&h=100" alt="Card image cap">
                <div class="card-block">
                    <h4 class="card-title">'.$liste['titre_mat'][$key].'</h4>
                    <p class="card-text">[Description du test]</p>
                   <a href="page_test_questions?id_mat='.$id_mat.'" name= "id_mat" value="Faire le Test" class="btn btn-primary">Faire le Test</a>
                </div>
                </div>';
            }
            
        }

        if(3%$key != 0)
        {
            echo'</div>';
        }


    ?>

	</body>

</html>