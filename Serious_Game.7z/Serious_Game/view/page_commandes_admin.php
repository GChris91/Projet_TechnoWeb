<!DOCTYPE html>

<html lang="fr">

	<head>

        <meta charset="utf-8">
		<link rel="stylesheet" href="css/style_page_commandes_admin.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
        
		<script src="js/scriptpage_commandes_admin.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/bootstrap.min.js"></script>
		

		<title>Commandes Admin</title>
		
	</head>

	<body>


    <?php include('navbar.php');?>

    <br/>
    <br/>

    <div class = "jumbotron">
   
       <div class = "container">
          <h1 class="text-center">Menu de commandes Administrateur [Nom+Prénom] </h1>
       </div>
       
    </div>

    <hr> 

    <div class="container">

            <div class="row">


                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">


                   <div class="container">

                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Confirmation Inscriptions
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_confirmation_inscriptions.php" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               [Commande]
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="#" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">

                <div class="container">
                  <div class="card hovercard">
                     <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                     <div class="avatar">
                        <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                     </div>
                     <div class="info">
                        <div class="title">
                           [Commande]
                        </div>
                        <div class="desc">Lorem ipsum</div>
                        <div class="desc">Lorem ipsum</div>
                        <div class="desc">Lorem ipsum</div>
                     </div>
                     <div class="bottom">
                        <a class="btn btn-primary" href="page_defis.php" role="button">Link</a>
                     </div>
                  </div>
                  
                </div>                
                </div>
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               [Commande]
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="#" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               [Commande]
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="#" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               [Commande]
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="#" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               [Commande]
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="#" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               [Commande]
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="#" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>
            </div>
    </div>

	</body>

</html>