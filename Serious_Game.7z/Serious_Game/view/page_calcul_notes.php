<!DOCTYPE html>

<html lang="fr">

	<head>
	
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/style_page_calcul_notes.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js/script_page_calcul_notes.js"></script>
		<script src="js/bootstrap.min.js"></script>
		

		<title> Calcul des notes </title>
		
	</head>

	<body>
		

		<div class="container">
		        <div class="row centered-form">
		        <div class="col-xs-12 col-sm-8 col-md-4 col-sm-offset-2 col-md-offset-4">
		        	<div class="panel panel-default">
		        		<div class="panel-heading">
					    		<h3 class="panel-title">Calcul Des Notes <small>Serious Game</small></h3>
					 			</div>
					 			<div class="panel-body">
					    		<form role="form">

					    			<div class="branches">
					    				Département :
						    			<select class="">
				                          <option>Sciences et Techniques</option>
				                          <option>...</option>
				                          <option>Littéraire</option>
				                        </select>
			                        </div>

			                        <br/>	

					    			<div class="branches">
					    				Cursus :
						    			<select class="">
				                          <option>Informatique</option>
				                          <option>...</option>
				                          <option>Math</option>
				                        </select>
			                        </div>
			                        <br/>
			                        <!-- Le bouton ci dessous déclenche une fenètre où l'utilisateur doit rentrer le chemin jusqu'à son fichier PDF contenant ses nôtes-->
			                        <input type="submit" value="Lien du PDF de vos notes" class="btn btn-info btn-block">
			                        <br/>					    			
					    			<input type="submit" value="Envoyer" class="btn btn-info btn-block">
					    		
					    		</form>
					    	</div>
			    		</div>
		    		</div>
		    	</div>
		    </div>

	</body>

</html>