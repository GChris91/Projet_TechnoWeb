<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>F.A.Q</title>

    <!-- Bootstrap Core CSS -->
    <link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/Serious_Game/view/css/style_page_faq.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <!-- jQuery -->
    <script src="/Serious_Game/view/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/Serious_Game/view/js/bootstrap.min.js"></script>

    <!-- Scrolling Nav JavaScript -->
    <script src="/Serious_Game/view/js/jquery.easing.min.js"></script>
    <script src="/Serious_Game/view/js/scrolling-nav.js"></script>


</head>

<!-- The #page-top ID is part of the scrolling feature - the data-spy and data-target are part of the built-in Bootstrap scrollspy function -->

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">Serious Game</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <!-- Hidden li included to remove active class from about link when scrolled up past about section -->
                    <li class="hidden">
                        <a class="page-scroll" href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#about">Paragraphe 1</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">Paragraphe 2</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#contact">Paragraphe 3</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Intro Section -->
    <section id="intro" class="intro-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Foire Aux Questions</h1>
                    <p>Bienvenue dans nôtre foir aux questions ! Vous trouverez ici l'ensemble des questions les plus posées accompagnées de leurs réponses</p>
                    <a class="btn btn-default page-scroll" href="#about">Vers la F.A.Q</a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Paragraphe 1</h1>

                    <pr>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in commodo enim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Pellentesque a mauris ut arcu facilisis fermentum ac consequat justo. Curabitur et felis nibh. Aliquam a ex sit amet nisi egestas convallis nec non orci. Aliquam non gravida magna, in tincidunt enim. Vestibulum sit amet convallis erat, vitae accumsan quam. Duis massa arcu, iaculis sit amet massa vel, eleifend ornare est. Morbi laoreet, magna a finibus commodo, dui arcu egestas erat, et blandit lorem purus eget ante. Curabitur arcu velit, consequat sit amet rutrum sed, eleifend mattis nunc. Morbi a lorem nec nulla iaculis dapibus in quis felis. Mauris at porttitor libero, a euismod dui. Aenean varius auctor finibus. Praesent tincidunt elementum tellus ac dignissim.

                    Sed sagittis nisl congue faucibus convallis. Vivamus massa eros, interdum nec fermentum ut, viverra maximus eros. Curabitur ut orci mattis, suscipit justo ac, malesuada libero. Fusce quis nisl arcu. Ut sed fringilla libero, sit amet dapibus metus. Aenean mauris ipsum, pharetra nec neque vel, commodo faucibus neque. Nullam tempor nulla vel nibh malesuada, eu tincidunt quam consectetur. Nunc imperdiet hendrerit porta. Vivamus rhoncus porttitor velit ut pharetra. Phasellus sit amet turpis mattis, ullamcorper tortor ut, rhoncus urna. Nam eget porta purus, et blandit purus. In at ex at nisl vestibulum tristique et id nisi.

                    </pr>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Paragraphe 2</h1>

                    <pr>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in commodo enim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Pellentesque a mauris ut arcu facilisis fermentum ac consequat justo. Curabitur et felis nibh. Aliquam a ex sit amet nisi egestas convallis nec non orci. Aliquam non gravida magna, in tincidunt enim. Vestibulum sit amet convallis erat, vitae accumsan quam. Duis massa arcu, iaculis sit amet massa vel, eleifend ornare est. Morbi laoreet, magna a finibus commodo, dui arcu egestas erat, et blandit lorem purus eget ante. Curabitur arcu velit, consequat sit amet rutrum sed, eleifend mattis nunc. Morbi a lorem nec nulla iaculis dapibus in quis felis. Mauris at porttitor libero, a euismod dui. Aenean varius auctor finibus. Praesent tincidunt elementum tellus ac dignissim.

                    Sed sagittis nisl congue faucibus convallis. Vivamus massa eros, interdum nec fermentum ut, viverra maximus eros. Curabitur ut orci mattis, suscipit justo ac, malesuada libero. Fusce quis nisl arcu. Ut sed fringilla libero, sit amet dapibus metus. Aenean mauris ipsum, pharetra nec neque vel, commodo faucibus neque. Nullam tempor nulla vel nibh malesuada, eu tincidunt quam consectetur. Nunc imperdiet hendrerit porta. Vivamus rhoncus porttitor velit ut pharetra. Phasellus sit amet turpis mattis, ullamcorper tortor ut, rhoncus urna. Nam eget porta purus, et blandit purus. In at ex at nisl vestibulum tristique et id nisi.

                    </pr>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Paragraphe 3</h1>

                    <pr>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in commodo enim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Pellentesque a mauris ut arcu facilisis fermentum ac consequat justo. Curabitur et felis nibh. Aliquam a ex sit amet nisi egestas convallis nec non orci. Aliquam non gravida magna, in tincidunt enim. Vestibulum sit amet convallis erat, vitae accumsan quam. Duis massa arcu, iaculis sit amet massa vel, eleifend ornare est. Morbi laoreet, magna a finibus commodo, dui arcu egestas erat, et blandit lorem purus eget ante. Curabitur arcu velit, consequat sit amet rutrum sed, eleifend mattis nunc. Morbi a lorem nec nulla iaculis dapibus in quis felis. Mauris at porttitor libero, a euismod dui. Aenean varius auctor finibus. Praesent tincidunt elementum tellus ac dignissim.

                    Sed sagittis nisl congue faucibus convallis. Vivamus massa eros, interdum nec fermentum ut, viverra maximus eros. Curabitur ut orci mattis, suscipit justo ac, malesuada libero. Fusce quis nisl arcu. Ut sed fringilla libero, sit amet dapibus metus. Aenean mauris ipsum, pharetra nec neque vel, commodo faucibus neque. Nullam tempor nulla vel nibh malesuada, eu tincidunt quam consectetur. Nunc imperdiet hendrerit porta. Vivamus rhoncus porttitor velit ut pharetra. Phasellus sit amet turpis mattis, ullamcorper tortor ut, rhoncus urna. Nam eget porta purus, et blandit purus. In at ex at nisl vestibulum tristique et id nisi.

                    </pr>

                    <br/>
                    <br/>

                    <a class="btn btn-primary" href="page_accueil_utilisateur.php" role="button">Retourner à l'accueil</a>

                </div>
            </div>
        </div>
    </section>

    
</body>

</html>
