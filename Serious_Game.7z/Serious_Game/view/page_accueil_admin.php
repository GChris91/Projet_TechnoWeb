<!DOCTYPE html>

<html lang="fr">

	<head>

        <meta charset="utf-8">
		<link rel="stylesheet" href="css/style_page_accueil_admin.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
        
		<script src="js/scriptpage_accueil_admin.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/bootstrap.min.js"></script>
		

		<title>Accueil Admin</title>
		
	</head>

	<body>


    <?php include('navbar.php');?>

    <br/>
    <br/>

    <div class = "jumbotron">
   
       <div class = "container">
          <h1 class="text-center">Bienvenue Administrateur [Nom+Prénom] !</h1>
       </div>
       
    </div>

    <hr> 

    <div class="container">

                       

            <div class="row">


                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">


                   <div class="container">

                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Mon Profil
                            </div>
                            <div class="desc"><a href="page_mdp_changer.php">Changer Mon Mot de Passe</a></div>
                            <div class="desc"><a href="page_calcul_notes.php">Calculer mes notes</a></div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_profil_admin.php" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Test
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_test.php" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">

                <div class="container">
                  <div class="card hovercard">
                     <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                     <div class="avatar">
                        <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                     </div>
                     <div class="info">
                        <div class="title">
                           Défis
                        </div>
                        <div class="desc">Lorem ipsum</div>
                        <div class="desc">Lorem ipsum</div>
                        <div class="desc">Lorem ipsum</div>
                     </div>
                     <div class="bottom">
                        <a class="btn btn-primary" href="page_defis.php" role="button">Link</a>
                     </div>
                  </div>
                  
                </div>                
                </div>
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Magasin
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_magasin.php" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Commandes Admin
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_commandes_admin.php" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>
                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Règles
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_regles.php" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               F.A.Q
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_faq.php" role="button">Link</a>
                         </div>
                      </div>
                    </div>        
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="container">
                      <div class="card hovercard">
                         <img src="http://placehold.it/300x200/000000/&text=Header" alt=""/>
                         <div class="avatar">
                            <img src="http://placehold.it/80X80/333333/&text=Head" alt="" />
                         </div>
                         <div class="info">
                            <div class="title">
                               Mon Clan
                            </div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                            <div class="desc">Lorem ipsum</div>
                         </div>
                         <div class="bottom">
                            <a class="btn btn-primary" href="page_clan.php" role="button">Link</a>
                         </div>
                      </div>
                      
                    </div>
                </div>
            </div>
    </div>

	</body>

</html>