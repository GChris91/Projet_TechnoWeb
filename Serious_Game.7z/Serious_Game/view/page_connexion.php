<!DOCTYPE html>

<html lang="fr">

	<head>

        <meta charset="utf-8">
		<link rel="stylesheet" href="/Serious_Game/view/css/style_page_connexion.css">
		<link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
		<script src="/Serious_Game/view/js/script_page_connexion.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title> Connexion </title>
		
	</head>

	<body>

		<!--
    you can substitue the span of reauth email for a input with the email and
    include the remember me checkbox
    -->
    <div class="container">
        <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            <img id="profile-img" class="profile-img-card" src="/Serious_Game/view/images/avatar.png" />
            <p id="profile-name" class="profile-name-card"></p>
            <form  action="page_connexion" method="post" enctype="multipart/form-data">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="text" name="nom_util" id="inputEmail" class="form-control" placeholder="Username" required autofocus>
                <input type="password" name="mot_de_passe" id="inputPassword" class="form-control" placeholder="Mot de Passe" required><br/>
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Connexion</button><br/>
            </form><!-- /form -->
            
            <a href="#" class="no-account">
                Vous n'avez pas encore de compte ?<br/><br/>
            </a>
            <a href="#" class="forgot-password">
                Avez vous oublié votre mot de passe ?<br/>
            </a>
            <a href="#" class="forgot-username">
                Avez vous oublié votre nom de compte ?<br/>
            </a>
        </div><!-- /card-container -->
    </div><!-- /container -->

	</body>

</html>