<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Règles</title>

    <!-- Bootstrap Core CSS -->
    <link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/Serious_Game/view/css/style_page_faq_regles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<!-- The #page-top ID is part of the scrolling feature - the data-spy and data-target are part of the built-in Bootstrap scrollspy function -->

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">Serious Game</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <!-- Hidden li included to remove active class from about link when scrolled up past about section -->
                    <li class="hidden">
                        <a class="page-scroll" href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#about">Général</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">Défis</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#contact">Tests</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Intro Section -->
    <section id="intro" class="intro-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Page des règles</h1>
                    <p>Bienvenue sur la page des règles ! Veuillez s'il vous plait lire ces règles avant de commencer à jouer.</p>
                    <a class="btn btn-default page-scroll" href="#about">Lire les règles</a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Général</h1>

                    <pr>-Chaque joueur a un avatar et un compte associé.<br/>
                        -Chaque joueur doit faire partie d'un clan (une classe universitaire)<br/>
                        -Ces clans sont classés par scores moyens<br/>
                        -L'avatar doit être créé en suivant le model ci-joint: http://southpark.cc.com/avatar<br/>

                    </pr>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Défis</h1>

                    <pr>-Les défis se font en 1v1 sauf cas suivant:<br/>
                        -Seul un chef de clan peut demander un défi à plusieurs personnes. Possibilité de 3v3, 4v4 ou 5v5. Leader contre leader, reste random contre random. En cas d'égalité, leader vs leader décise le gagnant.<br/>
                        -Un nombre maximal de défis peut être envoyé par jour, correspondant à 3 fois le nombre du niveau du joueur.<br/>
                        -Un défis envoyé et non accepté compte dans la limite.<br/>
                        -Nombre d'XP par question juste est le suivant: 50% pour votre matière (Info => Info), 100% pour autres matières du département (ex: Sciences, maths, physique, SVT = 100%), 150% pour matière opposée (droit, lettres, business...)<br/>
                        -Questions du défis uniquement si déjà répondu juste via autres défis lancé ou tests.<br/>
                        -Défis vers quelqu'un ou vers une personne aléatoire (option aléatoire à ajouté)<br/>
                        -Chaque partie choisi 3 questions. Les questions sont lancées de façon ping-pong. Premier joueur choisi au hasard. Celui qui a le plus de victoires gagnes. En cas d'égalité, celui qui a mis le moins de temps à répondre gagne.<br/>
                        -Temps de réponse: 30sec pour questions normales, 15 pour questions de votre discipline.<br/>
                        -On ne peut défier que les personnes dont le niveau de compétence générale (toutes disciplines confondues) est dans une marge de + ou - 10% de votre niveau.<br/>
                            Ex: si niveau 500/1000, peut que défier personnes entre 400 et 600.<br/>
                        -Toutes les discipplines commences à un niveau de compétence de 0, sauf celles augmentés via bulletins ou tests.<br/>

                    </pr>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <h1>Tests</h1>

                    <pr>

                    Niveau de compétences dans un test = moyenne des résultats des tests.<br/>
                    Ex: si test 1 = 7/10 de questions justes, test 2 = 6/10 et test 3 = 8/10. Compétences = 700/1000<br/>

                    </pr>

                    <h1>Autres</h1>

                    <pr>

                        -Option Sport: Si 15 ou plus en sport, alors pouvoir spécial: voir les stats des autres joueurs.<br/>
                        -Missions proposées chaques jour avec 200% d'XP sur une question au hasard<br/>

                    </pr>

                    <h1>Stats</h1>

                    <pr>

                        -Niveau<br/>
                        -Pouvoir Special (oui/non)<br/>
                    
                    </pr>

                    <br/>

                    <a class="btn btn-primary" href="page_accueil_utilisateur.php" role="button">Retourner à l'accueil</a>

                </div>
            </div>
        </div>
    </section>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Scrolling Nav JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrolling-nav.js"></script>

</body>

</html>
