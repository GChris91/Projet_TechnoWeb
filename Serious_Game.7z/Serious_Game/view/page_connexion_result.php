<!DOCTYPE html>

<html lang="fr">

	<head>

        <meta charset="utf-8">
		<link rel="stylesheet" href="Serious_Game/css/style_page_connexionA.css">
		<link href="Serious_Game/css/bootstrapQ.min.css" rel="stylesheet">
		<script src="Serious_Game/js/script_page_connexion.js"></script>
        <script src="Serious_Game/js/bootstrap.min.js"></script>
		

		<title> Connexion </title>
		
	</head>

	<body>

		<!--
    you can substitue the span of reauth email for a input with the email and
    include the remember me checkbox
    -->
    <div class="container">
        <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
<?php

            if (isset($_POST['username']) && strlen($_POST['username']) > 4){
                        $username = htmlspecialchars($_POST['username']);

                        if (isset($_POST['password']) && strlen($_POST['password'] >= 7)){
                                $password = htmlspecialchars($_POST['password']);

                                       try
                                       {
                                                   $bdd = new PDO('mysql:host=localhost;dbname=serious_game;charset=utf8', 'root', '');
                                       }
                                       catch(Exception $e)
                                       {
                                                  die('Erreur : '.$e->getMessage());
                                       }

                                       $passwordSalted = 'sweet'.$password;
                                       $passwordHashed = hash('sha256', $passwordSalted);

                                       $req = $bdd->prepare("SELECT id_util FROM utilisateur WHERE username = :username AND password = :password");
                                       $req->execute(array(
                                        'username' => $username,
                                        'password' => $passwordHashed));
                                      
                                       $donnees = $req->fetch();

                                       if (!$donnees ) {
                                        header("Location: page_connexion_error.php");

                                       }else{
                                        session_start();
                                        $_SESSION['id_util'] = $donnees['id_util'];
                                        $_SESSION['username'] = $username;
                                        header("Location: page_accueil_utilisateur.php");
                                        }


                        }else{$passwordErr = " Username ou mot de passe invalide";}
            }else{$usernameErr = "Username ou mot de asse invalide";}

    ?>


        </div><!-- /card-container -->
    </div><!-- /container -->

	</body>

</html>