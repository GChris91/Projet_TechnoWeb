<!DOCTYPE html>

<html lang="fr">

	<head>
    
        <meta charset="utf-8">
		<link rel="stylesheet" href="css/style_page_confirmation_inscriptions.css">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js/script_page_confirmation_inscriptions.js"></script>
        <script src="js/bootstrap.min.js"></script>
		

		<title> Confirmation Inscriptions </title>
		
	</head>

	<body>

    <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>

    <br/>
    <br/>
    <br/>

	<div class="container">

                <!-- Jumbotron Header -->
            <header class="jumbotron hero-spacer">
                <h2 class="text-center">Utilisateurs en attente de confirmation</h2>
            </header>

            <hr>

            <div class="row">

                <div class="col-xs-12 col-sm-offset-3 col-sm-6">
                        <div class="panel panel-default">
                            <div class="panel-heading c-list">
                                <span class="title">Liste des utilisateurs en attente de confirmation </span>
                            </div>
                            
                            <div class="row" style="display: none;">
                                <div class="col-xs-12">
                                    <div class="input-group c-search">
                                        <input type="text" class="form-control" id="contact-list-search">
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" type="button"><span class="glyphicon glyphicon-search text-muted"></span></button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <ul class="list-group" id="contact-list">
                                <li class="list-group-item">
                                    <div class="col-xs-12 col-sm-3">
                                        <img src="http://api.randomuser.me/portraits/men/49.jpg" alt="Scott Stevens" class="img-responsive img-circle" />
                                    </div>
                                    <div class="col-xs-12 col-sm-9">
                                        <span class="name">[Nom+Prénom du membre de clan]</span><br/>
                                        <br/>
                                        <button type="button" class="btn btn-primary">Confirmer</button>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                                <li class="list-group-item">
                                    <div class="col-xs-12 col-sm-3">
                                        <img src="http://api.randomuser.me/portraits/men/97.jpg" alt="Seth Frazier" class="img-responsive img-circle" />
                                    </div>
                                    <div class="col-xs-12 col-sm-9">
                                        <span class="name">[Nom+Prénom du membre de clan]</span><br/>
                                        <br/>
                                        <button type="button" class="btn btn-primary">Confirmer</button>                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                                <li class="list-group-item">
                                    <div class="col-xs-12 col-sm-3">
                                        <img src="http://api.randomuser.me/portraits/women/90.jpg" alt="Jean Myers" class="img-responsive img-circle" />
                                    </div>
                                    <div class="col-xs-12 col-sm-9">
                                        <span class="name">[Nom+Prénom du membre de clan]</span><br/>
                                        <br/>
                                        <button type="button" class="btn btn-primary">Confirmer</button>                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                                <li class="list-group-item">
                                    <div class="col-xs-12 col-sm-3">
                                        <img src="http://api.randomuser.me/portraits/men/24.jpg" alt="Todd Shelton" class="img-responsive img-circle" />
                                    </div>
                                    <div class="col-xs-12 col-sm-9">
                                        <span class="name">[Nom+Prénom du membre de clan]</span><br/>
                                        <br/>
                                        <button type="button" class="btn btn-primary">Confirmer</button>                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                                <li class="list-group-item">
                                    <div class="col-xs-12 col-sm-3">
                                        <img src="http://api.randomuser.me/portraits/women/34.jpg" alt="Rosemary Porter" class="img-responsive img-circle" />
                                    </div>
                                    <div class="col-xs-12 col-sm-9">
                                        <span class="name">[Nom+Prénom du membre de clan]</span><br/>
                                        <br/>
                                        <button type="button" class="btn btn-primary">Confirmer</button>                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                                <li class="list-group-item">
                                    <div class="col-xs-12 col-sm-3">
                                        <img src="http://api.randomuser.me/portraits/women/56.jpg" alt="Debbie Schmidt" class="img-responsive img-circle" />
                                    </div>
                                    <div class="col-xs-12 col-sm-9">
                                        <span class="name">[Nom+Prénom du membre de clan]</span><br/>
                                        <br/>
                                        <button type="button" class="btn btn-primary">Confirmer</button>                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                                <li class="list-group-item">
                                    <div class="col-xs-12 col-sm-3">
                                        <img src="http://api.randomuser.me/portraits/women/76.jpg" alt="Glenda Patterson" class="img-responsive img-circle" />
                                    </div>
                                    <div class="col-xs-12 col-sm-9">
                                        <span class="name">[Nom+Prénom du membre de clan]</span><br/>
                                        <br/>
                                        <button type="button" class="btn btn-primary">Confirmer</button>                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                            </ul>
                        </div>
                    </div>
                
            </div>
        </div>


	</body>

</html>