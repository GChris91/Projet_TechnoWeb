<!DOCTYPE html>

<html lang="fr">

	<head>

        <meta charset="utf-8">
        <link rel="stylesheet" href="/Serious_Game/view/css/style_profil_utilisateur.css">
        <link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
        
        <script src="/Serious_Game/view/js/script_profil_utilisateur.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title> Profil Utilisateur</title>
		
	</head>

	<body>
    
    <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>

    <hr class="">
    <div class="container target">
        <div class="row">
            <div class="col-sm-10">
                 <h1 class=""><?php echo $infoprofil['nom_util'] ?></h1>
             
              <button type="button" class="btn btn-success">Demande Amis</button>  <button type="button" class="btn btn-info">Message Privé</button>
    <br>
            </div>
          <div class="col-sm-2"><a href="/users" class="pull-right"><img title="profile image" class="img-circle img-responsive" src="http://www.rlsandbox.com/img/profile.jpg"></a>

            </div>
        </div>
      <br>
        <div class="row">
            <div class="col-sm-3">
                <!--left col-->
                <ul class="list-group">
                    <li class="list-group-item text-muted" contenteditable="false">Profile</li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Nom</strong></span> <?php echo $infoprofil['nom'] ?></li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Prénom</strong></span> <?php echo $infoprofil['prenom'] ?></li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Université</strong></span> <?php echo $infoprofil['nom_univ'] ?></li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Clan </strong></span> <?php echo $infoprofil['nom_fil'] ?></li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Niveau </strong></span> <?php echo $infoprofil['niveau'] ?></li>
                </ul>
              
                <ul class="list-group">
                    <li class="list-group-item text-muted">Contacts <i class="fa fa-dashboard fa-1x"></i>

                    </li><li class="list-group-item text-right"><span class="pull-left"><strong class="">Adresse Mail</strong></span> <?php echo $infoprofil['email'] ?></li></ul>
                
            </div>
            <!--/col-3-->
            <div class="col-sm-9" style="" contenteditable="false">
                <div class="panel panel-default">
                    <div class="panel-heading">Information Notes</div>
                    <div class="panel-body">                     
                    <?php
                                $mat = array($notes['titre_mat'][0], $notes['titre_mat'][1], $notes['titre_mat'][2], $notes['titre_mat'][3], $notes['titre_mat'][4], $notes['titre_mat'][5]);
                                $score = array($notes['nb_point'][0], $notes['nb_point'][1], $notes['nb_point'][2], $notes['nb_point'][3], $notes['nb_point'][4], $notes['nb_point'][5]);
                                
                                for ($i=0; $i <6 ; $i++) 
                                { 
                                        echo $mat[$i].': '.$score[$i].'<br/>';
                                }
                             /*
                            echo '<pre>';
                            print_r($notes);
                            echo '</pre>';*/

                             //echo $notes['titre_mat'][$i].'<br/>';
                             //echo $notes['nb_point'][$i];         
                            ?>   

                    </div>
                </div>
            
               <div class="panel panel-default">
                    <div class="panel-heading">Ajout Bulletins Notes</div>
                    <div class="panel-body"> 
                        <form>
                                <form  action="page_profil_utilisateur" method="post" enctype="multipart/form-data">
                                <select name="matiere1">
                                  <option value=""> Matiere...</option>
                                  <option value="1">Arts et Littérature</option>
                                  <option value="2">Sciences et Nature</option>
                                  <option value="3">Histoire</option>
                                  <option value="4">Géographie</option>
                                  <option value="5">Mathématique</option>
                                  <option value="6">Informatique</option>
                                  <option value="7">Physique et Chimie</option>
                                </select>
                                <input type="text" name="note1" placeholder="Note">
                                                  <br/>             
                                <select name="matiere2">
                                  <option value=""> Matiere...</option>
                                  <option value="1">Arts et Littérature</option>
                                  <option value="2">Sciences et Nature</option>
                                  <option value="3">Histoire</option>
                                  <option value="4">Géographie</option>
                                  <option value="5">Mathématique</option>
                                  <option value="6">Informatique</option>
                                  <option value="7">Physique et Chimie</option>
                                </select>
                                <input type="text" name="note2" placeholder="Note">
                                                <br/>
                                  <select name="matiere3">
                                  <option value=""> Matiere...</option>
                                  <option value="1">Arts et Littérature</option>
                                  <option value="2">Sciences et Nature</option>
                                  <option value="3">Histoire</option>
                                  <option value="4">Géographie</option>
                                  <option value="5">Mathématique</option>
                                  <option value="6">Informatique</option>
                                  <option value="7">Physique et Chimie</option>
                                </select>
                                <input type="text" name="note3" placeholder="Note">
                                                  <br/>             
                                <select name="matiere4">
                                  <option value=""> Matiere...</option>
                                  <option value="1">Arts et Littérature</option>
                                  <option value="2">Sciences et Nature</option>
                                  <option value="3">Histoire</option>
                                  <option value="4">Géographie</option>
                                  <option value="5">Mathématique</option>
                                  <option value="6">Informatique</option>
                                  <option value="7">Physique et Chimie</option>
                                </select>
                                <input type="text" name="note4" placeholder="Note">
                                                <br/>
                                <select name="matiere5">
                                  <option value=""> Matiere...</option>
                                  <option value="1">Arts et Littérature</option>
                                  <option value="2">Sciences et Nature</option>
                                  <option value="3">Histoire</option>
                                  <option value="4">Géographie</option>
                                  <option value="5">Mathématique</option>
                                  <option value="6">Informatique</option>
                                  <option value="7">Physique et Chimie</option>
                                </select>
                                <input type="text" name="note5" placeholder="Note">
                                                  <br/>             
                                <select name="matiere6">
                                  <option value=""> Matiere...</option>
                                  <option value="1">Arts et Littérature</option>
                                  <option value="2">Sciences et Nature</option>
                                  <option value="3">Histoire</option>
                                  <option value="4">Géographie</option>
                                  <option value="5">Mathématique</option>
                                  <option value="6">Informatique</option>
                                  <option value="7">Physique et Chimie</option>
                                </select>
                                <input type="text" name="note6" placeholder="Note">

                        </form>

                    </div>
    </div></div>


                <div id="push"></div>
            </div>
            <footer id="footer">
                    <div class="span3">
                        <span class="pull-right">©Copyright 2017 Serious Game</span>
                    </div>
                </div>
            </footer>
        
    </div>

    
	</body>

</html>