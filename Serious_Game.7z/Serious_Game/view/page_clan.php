<!DOCTYPE html>

<html lang="fr">

	<head>

		<meta charset="utf-8">
		<link rel="stylesheet" href="/Serious_Game/view/css/style_page_clan.css">
		<link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
		<script src="/Serious_Game/view/js/script_page_clan.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
		

		<title> Page de Clan </title>
		
	</head>

	<body>

		<?php include('navbar.php');?>

	    <br/>
	    <br/>
	    <br/>

		
		<div class="container">
		    <div class="fb-profile">
		        <img align="left" class="fb-image-lg" src="http://lorempixel.com/850/280/nightlife/5/" alt="Profile image example"/>
		        <img align="left" class="fb-image-profile thumbnail" src="http://lorempixel.com/180/180/people/9/" alt="Profile image example"/>
		        <div class="fb-profile-text">
		            <h1>[Nom du Clan]</h1>
		            <p>[Nom+Prénom du chef de clan]</p>
		        </div>
		    </div>
		</div> <!-- /container -->  


		<div class="container">
		  

		    <div class="row">
			        <div class="col-xs-12 col-sm-offset-3 col-sm-6">
			            <div class="panel panel-default">
			                <div class="panel-heading c-list">
			                    <span class="title">Membres du clan</span>
			                </div>
			                
			                <div class="row" style="display: none;">
			                    <div class="col-xs-12">
			                        <div class="input-group c-search">
			                            <input type="text" class="form-control" id="contact-list-search">
			                            <span class="input-group-btn">
			                                <button class="btn btn-default" type="button"><span class="glyphicon glyphicon-search text-muted"></span></button>
			                            </span>
			                        </div>
			                    </div>
			                </div>
			                
			                <ul class="list-group" id="contact-list">
			                    <li class="list-group-item">
			                        <div class="col-xs-12 col-sm-3">
			                            <img src="http://api.randomuser.me/portraits/men/49.jpg" alt="Scott Stevens" class="img-responsive img-circle" />
			                        </div>
			                        <div class="col-xs-12 col-sm-9">
			                            <span class="name">[Nom+Prénom du membre de clan]</span><br/>
			                            
			                        </div>
			                        <div class="clearfix"></div>
			                    </li>
			                    <li class="list-group-item">
			                        <div class="col-xs-12 col-sm-3">
			                            <img src="http://api.randomuser.me/portraits/men/97.jpg" alt="Seth Frazier" class="img-responsive img-circle" />
			                        </div>
			                        <div class="col-xs-12 col-sm-9">
			                            <span class="name">[Nom+Prénom du membre de clan]</span><br/>
			                            
			                        </div>
			                        <div class="clearfix"></div>
			                    </li>
			                    <li class="list-group-item">
			                        <div class="col-xs-12 col-sm-3">
			                            <img src="http://api.randomuser.me/portraits/women/90.jpg" alt="Jean Myers" class="img-responsive img-circle" />
			                        </div>
			                        <div class="col-xs-12 col-sm-9">
			                            <span class="name">[Nom+Prénom du membre de clan]</span><br/>
			                            
			                        </div>
			                        <div class="clearfix"></div>
			                    </li>
			                    <li class="list-group-item">
			                        <div class="col-xs-12 col-sm-3">
			                            <img src="http://api.randomuser.me/portraits/men/24.jpg" alt="Todd Shelton" class="img-responsive img-circle" />
			                        </div>
			                        <div class="col-xs-12 col-sm-9">
			                            <span class="name">[Nom+Prénom du membre de clan]</span><br/>
			                            
			                        </div>
			                        <div class="clearfix"></div>
			                    </li>
			                    <li class="list-group-item">
			                        <div class="col-xs-12 col-sm-3">
			                            <img src="http://api.randomuser.me/portraits/women/34.jpg" alt="Rosemary Porter" class="img-responsive img-circle" />
			                        </div>
			                        <div class="col-xs-12 col-sm-9">
			                            <span class="name">[Nom+Prénom du membre de clan]</span><br/>
			                            
			                        </div>
			                        <div class="clearfix"></div>
			                    </li>
			                    <li class="list-group-item">
			                        <div class="col-xs-12 col-sm-3">
			                            <img src="http://api.randomuser.me/portraits/women/56.jpg" alt="Debbie Schmidt" class="img-responsive img-circle" />
			                        </div>
			                        <div class="col-xs-12 col-sm-9">
			                            <span class="name">[Nom+Prénom du membre de clan]</span><br/>
			                            
			                        </div>
			                        <div class="clearfix"></div>
			                    </li>
			                    <li class="list-group-item">
			                        <div class="col-xs-12 col-sm-3">
			                            <img src="http://api.randomuser.me/portraits/women/76.jpg" alt="Glenda Patterson" class="img-responsive img-circle" />
			                        </div>
			                        <div class="col-xs-12 col-sm-9">
			                            <span class="name">[Nom+Prénom du membre de clan]</span><br/>
			                            
			                        </div>
			                        <div class="clearfix"></div>
			                    </li>
			                </ul>
			            </div>
			        </div>
				</div>
			    
			</div>

    
	</body>

</html>