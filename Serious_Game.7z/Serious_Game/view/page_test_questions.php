<!DOCTYPE html>

<html lang="fr">

    <head>

        <meta charset="utf-8">
        <link rel="stylesheet" href="/Serious_Game/view/css/style_page_test.css">
        <link href="/Serious_Game/view/css/bootstrap.min.css" rel="stylesheet">
        <script src="/Serious_Game/view/js/script_page_test.js"></script>
        <script src="/Serious_Game/view/js/bootstrap.min.js"></script>
        

        <title> Tests </title>
        
    </head>

    <body>

    <?php include('navbar.php');?>

    <br/>
    <br/>
    <br/>

    <br/>
    <br/>
    <br/>


<?php
   require_once 'model.php';

    if(isset($_SESSION['nom_util']) && isset($_GET['sujet']))
    {
        open_database_connection();
        acceuil_action($error);
        $result = prepare_test($_SESSION['nom_util'], $id_mat);
        //print_r($result);
        $question = recup_description_question_multi($result);
        $reponse = recup_rep_multi($result);
    }

        $i = 0;

        
        foreach ($question['id_q'] as $id_q1)
        {

            echo '<br/><br/>'.($question['description'][$i].":"."<br/><br/>");

            foreach ($reponse['description'] as $key => $description)
            {
                if($reponse['id_q'][$key] == $id_q1)
                {
                    echo '<input type="radio" name="reponse">'.$description . '<br/>';
                }  
            }
        }




?>
    <br/>
    <br/>
    <br/>

    <br/>
    <br/>
    <br/>

<?php
/*
        foreach ($reponse['id_q'] as $id_q2)
            {
                if($id_q1 == $id_q2)
                {
                    echo '<input type="radio" name="reponse">'.$reponse['description'][$j].'<br/>';
                }
                $j++;
            }
?>
                    <input type="submit" name= 'validation' value="Valider">
                    </form>
<?php
                    //printf($reponse['description'][$j].",");
                    //echo '<tr>'.$reponse['description'][$j].'<br/><th>';
 */           
?>


    </body>

</html>